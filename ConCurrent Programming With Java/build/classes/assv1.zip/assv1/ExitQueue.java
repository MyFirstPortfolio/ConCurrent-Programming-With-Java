package assv1;

public class ExitQueue {

}
