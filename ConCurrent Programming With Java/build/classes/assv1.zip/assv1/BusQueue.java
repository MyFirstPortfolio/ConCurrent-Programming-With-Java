package assv1;
public class BusQueue {

    
    Buses b;
    public BusQueue(){
    }
    
    void add2Q(Buses b) {
        if (!"rejected".equals(b.getNumber())){
        System.out.println(b.getNumber() +" Entered the queue ");
       // System.out.println("Mantanience "+b.getMaintenace());
        //System.out.println("Cleaning "+b.getclean());
       }else
       {
            System.out.println("Healthy Bus pass By saying Hello");
       }
    } 
}
