package assv1;

public class ParkingLot {

    int plots = 10;
}
