package assv1;

public class Ramp {

    void Enter() {
        //Enter if Parking is not full 
        // move pus to parking
    }

    void Exit() {
        //if there is a bus in exitque
        //then let ti exit before
    }
}
